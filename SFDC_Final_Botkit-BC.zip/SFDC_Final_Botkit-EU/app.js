var Application = require('./lib/app');
var Server = require('./lib/server');
var sdk = require('./lib/sdk');
var config = require('./config.json');

var app = new Application(null, config);
var server = new Server(config, app);

server.start();
sdk.registerBot(require('./BotKit.js'));
//sdk.registerBot(require('./SampleBotKitSDKImplementation.js'));
var routes = app.load();
module.exports = routes;


////// App.js
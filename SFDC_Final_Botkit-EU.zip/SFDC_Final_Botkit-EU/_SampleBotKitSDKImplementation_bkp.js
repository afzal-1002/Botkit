var config = require("./config");
var botId = Object.keys(config.credentials);
var sdk = require("./lib/sdk");
var Promise = require("bluebird");
var api = require('./salesforceLiveChatAPI.js');
var _ = require('lodash');
var debug = require('debug')("Agent");
var redisOperations = require('./lib/redisOperations');
var VisitorTimeOutEvent = require("./VisitorTimeOutEvent.js");
//var utils = require("./utils");
var messageConf = require('./messages.json');
var schedular = require('node-schedule');
var rp = require('request-promise');
var LANGUAGE = require('./languages.json');
var _map = {}; //used to store secure session ids //TODO: need to find clear map var
var userDataMap = {}; //this will be use to store the data object for each user
var userResponseDataMap = {};
var historyIgnoreMessages = ["INITIAL DIALOG", "#session_closed"];
var lastUserMessages = {};  //used to store the last user message, key is the visitorId
var dateFrom;
var requestObjectForCase = {};
var useCase="";
var AgentID="";
var ack=-1;
var chatHistory="";

async function getPendingMessages(visitorId, session_key, affinity_token, count) {
    count = count || 1;
    console.log("BotKit.js | Count :" + count, "|" + visitorId);
    debug("BotKit.js | Count :" + count, "|" + visitorId, session_key, affinity_token);
    var endChat = false;
    var agentClosed = false;
    redisOperations.getRedisData("data:" + visitorId).then(async function (data) {
        //Comment below line for sentinel.
        //data = userDataMap[visitorId];
        console.log("| Data object | SampleBotKitSDKImplementation| : ", data);
        if(data) {
        api.getPendingMessages(session_key, affinity_token, ack++)
        .then(function(res) {
            visitor_id = visitorId;
            console.log("Called getPendingMessages from SampleBotKitSDK.");
            var data = userDataMap[visitorId];
            console.log("Polling", JSON.stringify(res));
            _.each(res.messages, function(event, key) {
                console.log("Now event type is, ", event.type);
                console.log(" ______ Response messages ______ ", res.messages);
                for(var i=0;i<res.messages.length;i++) {
                    if(res.messages[i].type == "ChatMessage") {
                        AgentID=res.messages[i].message.agentId;
                        requestObjectForCase.ownerID = AgentID;
                    }
                }
                if(event.type === "ChatRequestSuccess") {
                    console.log("Inside ChatRequestSuccess, sending chat history: ", chatHistory);
                //     var message = await getChatHistory(visitorId);
                //         message = formatChatHistory(message);
                //         chatHistory = {
                //             text: "Hi, below is the Chat History. \n" + message
                //         }
                //     api.sendMsg(session_key, affinity_token, chatHistory)
                //     .catch(function (e) {
                //     console.error(e);
                //     delete userDataMap[visitorId];
                //     delete _map[visitorId];
                //     console.error("connectToAgent | BotKit.js | Error while Sending Transcript |", visitorId, err);
                //     redisOperations.deleteRedisData("data:" + visitorId);
                //     redisOperations.deleteRedisData("entry:" + visitorId);
                //     redisOperations.deleteRedisData("connected:" + visitorId);
                //     VisitorTimeOutEvent.delete(data);
                //     return;
                // })
                return api.sendMsg(session_key, affinity_token, chatHistory).catch(function (err) {
                    console.error("connectToAgent | BotKit.js | Error while Sending Transcript |", visitorId, err);
                    redisOperations.deleteRedisData("data:" + visitorId);
                    redisOperations.deleteRedisData("entry:" + visitorId);
                    redisOperations.deleteRedisData("connected:" + visitorId);
                    VisitorTimeOutEvent.delete(data);
                    return;
                });
                } else if (event.type === "ChatEstablished") {
                    console.log("BotKit.js | ChatEstablished | ", visitorId);
                    agentAvailable = true;
                    var timeout = event.message.chasitorIdleTimeout.timeout
                    data.context.session_key = session_key;
                    data.context.affinity_token = affinity_token;
                    VisitorTimeOutEvent.add(data, timeout);
                } else if (event.type === "ChatMessage") {
                    debug('replying ', event);
                    console.log("BotKit.js | ChatMessage (FromAgent) | ", visitorId);
                    agentAvailable = true;
                    data.message = event.message.text;
                    var initials = event.message.name.match(/\b\w/g) || [];
                    initials = ((initials.shift() || '') + (initials.pop() || '')).toUpperCase();
                    var overrideMessagePayload = {
                        body: JSON.stringify({
                            "type": "template",
                            "payload": {
                                "template_type": "live_agent",
                                "text": event.message.text,
                                "agent_name": initials
                            }
                        }),
                        isTemplate: true
                    };
                    data.overrideMessagePayload = overrideMessagePayload;
                    var interval = key >= 1 ? 1000 * (key) : 0;
                    setTimeout(function(tempdata) {
                        return sdk.sendUserMessage(tempdata, function(err) {
                           // console.log("err", err);
                            if (err) {
                                return api.endChat(session_key, affinity_token).then(function(re) {
                                    getChatHistoryAndCreateCase(visitorId, "New", true).catch(function(err) {
                                        console.log(err);
                                        return err;
                                    });
                                    redirectToWelcomeIntent(visitorId);
                                    return closeChat(tempdata);
                                });
                            }
                        }).catch(function(e) {
                            console.error("BotKit.js | ChatMessage (FromAgent) | ", e);
                        });
                        }, interval, _.clone(data));
                    } else if (event.type === "ChatEnded") {
                        endChat = true;
                        VisitorTimeOutEvent.delete(data);
                        redisOperations.deleteRedisData("entry:" + visitorId);
                        redisOperations.deleteRedisData("data:" + visitorId);
                        redisOperations.deleteRedisData("connected:" + visitorId);
                        sdk.clearAgentSession(data);
                        console.log("BotKit.js | ChatEnded | ", visitorId);
                        // console.log('chat_closed');
                        // delete userResponseDataMap[visitorId];
                        // delete _map[visitorId];
                        getChatHistoryAndCreateCase(visitorId, "New", true).catch(function(err) {
                            console.log(err);
                            return err;
                        });
                        redirectToWelcomeIntent(visitorId);
                    } else if (event.type === "ChatRequestFail") {
                        console.log("BotKit.js | ChatRequestFail | ", visitorId);
                        redisOperations.deleteRedisData("entry:" + visitorId)
                        redisOperations.deleteRedisData("data:" + visitorId)
                        redisOperations.deleteRedisData("connected:" + visitorId)
                        endChat = true;
                        agentAvailable = false;
                        sdk.clearAgentSession(data);
                        console.log('Agents unavailable');
                        data.message = LANGUAGE["AGENT_NOT_AVAILABLE_1"][currentLanguage];
                        data.overrideMessagePayload = null;
                        console.log("Clearing maps and agent session...");
                        return sdk.sendUserMessage(data).then(async function() {
                            console.log("Sent user message.");
                            data.message = LANGUAGE["AGENT_NOT_AVAILABLE_2"][currentLanguage];
                            var response = await getChatHistoryAndCreateCase(visitorId, "With dealer", false).catch((err) => {console.log(err);})
                            if(typeof response != 'undefined') {
                            console.log("Fetching the Case number: ", response.CaseNumber);
                            data.message = data.message.replace("CASE_NUMBER", response.CaseNumber);
                                sdk.sendUserMessage(data).then(function() {
                                console.log("Sent user message.");
                                }).catch(function(err) {
                                    console.log(err);
                                    return err;
                                });
                                }
                                redirectToWelcomeIntent(visitorId);
                                }).catch(function(err) {
                                    console.log(err);
                                    return err;
                                });
                }
            });
            if (endChat)
                console.log(" BotKit.js | PollingStop | ", "Count : ", count, " | ", visitorId);
            if (agentClosed) {
                console.log("Agent is set as closed.");
                clearAgentNotification(data, visitorId);
            }
                
            if (!endChat)
                getPendingMessages(visitorId, session_key, affinity_token, count + 1);
        })
        .catch(function (e) {
            console.error("BotKit.js | ERROR From getMessages Api | Error Code | ", e.statusCode);
            if (e.statusCode === 403)
                console.info("BotKit.js | Removing Expired Session from Redis |", visitorId);
            clearAgentNotification(data, visitorId);
        });  
    }
        
    else
    {
        console.log("BotKit.js | Data not found | ",visitorId);
        console.log("BotKit.js | PollingStop  | ",visitorId);
    }
    }).catch(function (error) {
        console.error("BotKit.js | ERROR While Retriving Redis Data | ", error);
    });
}

function sleep(ms) {
    return new Promise((resolve) => {
      setTimeout(resolve, ms);
    });
  }


// schedular.scheduleJob('*/5 * * * * *', function() {
//     debug('schedular triggered');
//     var promiseArr = [];
//     redisOperations.getRedisKeys().then(function (keys) {
//         console.log('|Inside Scheduler | BotKit.js | Count ', keys.length);
//         for (var i = 0; i < keys.length; i++) {
//             redisOperations.getRedisData(keys[i]).then(async function (data) {
//                 promiseArr.push(getPendingMessages(data.visitorId, data.session_key, data.affinity_token).then()
//                 .catch(function (err) {
//                     console.error('|restartPolling | BotKit.js | error while restarting polling for ', data.visitorId,err);
//                 }));
//             });
//         }
//     });
//     return Promise.all(promiseArr).then(function() {
//         debug('scheduled finished');
//     }).catch(function(e) {
//         debug('error in schedular', e);
//     });
// });

function retrieveBotUserContextAndConstructCaseRequest(data) {  
    dateFrom  = _.get(data, 'context.session.BotUserSession.dateFrom');
    var forgeRockID = _.get(data, 'context.session.BotUserSession.ForgerockID');
    var partNumber = _.get(data, 'context.session.BotUserSession.PartNumber');
    var category = _.get(data, 'context.session.BotUserSession.category');
    var subCategory = _.get(data, 'context.session.BotUserSession.sub_category');
    var subject = _.get(data, 'context.session.BotUserSession.subject');
    currentLanguage = _.get(data, 'context.currentLanguage');
    var boxNumber = _.get(data, 'context.session.BotUserSession.BoxNumber');
    var salesOrderNumber = _.get(data, 'context.session.BotUserSession.SalesOrderNumber');
    var invoiceNumber=_.get(data, 'context.session.BotUserSession.InvoiceNumber');
    var returnNumber=_.get(data, 'context.session.BotUserSession.ReturnNumber');
    var AGCOCurrentRetailPrice = _.get(data, 'context.session.BotUserSession.AGCOCurrentRetailPrice');
    var CompetitorName = _.get(data, 'context.session.BotUserSession.CompetitorName');
    var CurrentAnnualPurchase = _.get(data, 'context.session.BotUserSession.CurrentAnnualPurchase');
    var PotentialPurchaseQuantity = _.get(data, 'context.session.BotUserSession.PotentialPurchaseQuantity');
    var CompetitorNetPrice = _.get(data, 'context.session.BotUserSession.CompetitorNetPrice');
    var CompetitorRetailPrice = _.get(data, 'context.session.BotUserSession.CompetitorRetailPrice');
    var CompetitorPart = _.get(data, 'context.session.BotUserSession.CompetitorPart');
    var ReasonForPriceAdjustment = _.get(data, 'context.session.BotUserSession.ReasonForPriceAdjustment');
    var SuggestedAGCORetailPrice = _.get(data, 'context.session.BotUserSession.SuggestedAGCORetailPrice');
    var SuggestedAGCONetPrice = _.get(data, 'context.session.BotUserSession.SuggestedAGCONetPrice');
    var ComparableAGCOPart = _.get(data, 'context.session.BotUserSession.ComparableAGCOPart');
    var ConfirmedOrderQtyIfPriceAdjusted = _.get(data, 'context.session.BotUserSession.ConfirmedOrderQtyIfPriceAdjusted');
    var ProposedAGCONetPrice = _.get(data, 'context.session.BotUserSession.ProposedAGCONetPrice');
    useCase = _.get(data,'context.session.BotUserSession.UCNumber');
    var pricing = false;
    console.log("=========Forgerock ID=========", forgeRockID);
    if(useCase == 'UC29') {
        pricing = true;
    }
    requestObjectForCase = {
        forgeRockID : forgeRockID,
        partNumber : partNumber,
        category : category,
        subCategory : subCategory,
        subject : subject,
        boxNumber : boxNumber,
        salesOrderNumber : salesOrderNumber,
        invoiceNumber : invoiceNumber,
        returnNumber : returnNumber,
        ownerID : AgentID,
        language: currentLanguage,
        pricing: pricing,
        AGCOCurrentRetailPrice: AGCOCurrentRetailPrice,
        CompetitorName: CompetitorName,
        CurrentAnnualPurchase: CurrentAnnualPurchase,
        PotentialPurchaseQuantity: PotentialPurchaseQuantity,
        CompetitorNetPrice: CompetitorNetPrice,
        CompetitorRetailPrice: CompetitorRetailPrice,
        CompetitorPart: CompetitorPart,
        ReasonForPriceAdjustment: ReasonForPriceAdjustment,
        SuggestedAGCORetailPrice: SuggestedAGCORetailPrice,
        SuggestedAGCONetPrice: SuggestedAGCONetPrice,
        ComparableAGCOPart: ComparableAGCOPart,
        ConfirmedOrderQtyIfPriceAdjusted: ConfirmedOrderQtyIfPriceAdjusted,
        ProposedAGCONetPrice: ProposedAGCONetPrice,
        useCase: useCase
    }
}

async function connectToAgent(requestId, data, cb) {
    var visitorId = _.get(data, 'channel.channelInfos.from');
    if (!visitorId) {
        visitorId = _.get(data, 'channel.from');
    }

    
    console.log("|connectToAgent | BotKit.js | visitorId ", visitorId);
    console.log("|connectToAgent | BotKit.js | AgentId ", requestObjectForCase.AgentID);
    redisOperations.updateRedisWithUserData(visitorId, data).then(function () {
        console.log("|connectToAgent | BotKit.js | updateRedisWithUserData |", visitorId);
        redisOperations.setTtl("data", visitorId);
    })
    currentLanguage = _.get(data, 'context.currentLanguage');
    console.log("Current language detected: ", currentLanguage);
    var buttonId;
    if(currentLanguage == "fr") {
        console.log("Contacting French Customer Support.");
        api.getCaseAccessTokenAndButtonID(config.live_agent.buttonNameFR).then(function(buttonId) {
            return checkAgentStatusAndConnect(requestId, data, cb, buttonId);
        }).catch(function (e) {
            debug('error in connecting to agent', e);
        });
    }
    else if(currentLanguage == "de") {
        console.log("Contacting German Customer Support");
        api.getCaseAccessTokenAndButtonID(config.live_agent.buttonNameDE).then(function(buttonId) {
            return checkAgentStatusAndConnect(requestId, data, cb, buttonId);
        }).catch(function (e) {
            debug('error in connecting to agent', e);
        });
    }
    else {
        console.log("Contacting English Customer Support");
        api.getCaseAccessTokenAndButtonID(config.live_agent.buttonNameUK).then(function(buttonId) {
            return checkAgentStatusAndConnect(requestId, data, cb, buttonId);
        }).catch(function (e) {
            debug('error in connecting to agent', e);
        });  
    }
}

async function checkAgentStatusAndConnect(requestId, data, cb, buttonId) {
    console.log("Button ID: ", buttonId);
            console.log("Live agent connection");
            var visitorId = _.get(data, 'channel.channelInfos.from');
            if (!visitorId) {
                visitorId = _.get(data, 'channel.from');
            }
            retrieveBotUserContextAndConstructCaseRequest(data);
            userDataMap[visitorId] = data;
            var context = data.context;
            try {
                const session = await api.getSession();
                var customData ="";
                var options = customData || {};
                options.buttonId = buttonId;
                options.VisitorName = visitorId;
                console.log("|connectToAgent | BotKit.js | Request for initChat |", visitorId, "|", options.uri);
                console.log(`options: `+options);
                await api.initChat(session, options);
                var redisEntry = {
                session_key: session.key,
                affinity_token: session.affinityToken,
                visitorId: visitorId,
            };
            // sdk.startAgentSession(data, cb);
            // _map[visitorId] = {
            //     session_key: session.key,
            //     affinity_token: session.affinityToken,
            //     visitorId: visitorId,
            //     last_message_id: 0
            // };
            redisOperations.updateRedisWithEntry(visitorId, redisEntry).then(function () {
                console.log("|connectToAgent | BotKit.js | updateRedisWithEntry |", visitorId);
                redisOperations.setTtl("entry", visitorId);
                var connectToAgent = { "server": 1, "time": new Date() }
                redisOperations.updateRedisConnectedAgent(visitorId, connectToAgent).then(function () {
                    redisOperations.setTtl("connected", visitorId);
                    VisitorTimeOutEvent.add(data);
                    getChatHistory(visitorId).then(async (message) => {
                        message = formatChatHistory(message);
                        chatHistory = {
                            text: "Hi, below is the Chat History. \n" + message
                        }
                        await sleep(3000);
                        // console.log("|connectToAgent | BotKit.js | PollingStarted |  ", visitorId);
                        api.sendMsg(session.key, session.affinityToken, chatHistory).catch(function (err) {
                            console.error("connectToAgent | BotKit.js | Error while Sending Transcript |", visitorId, err);
                            redisOperations.deleteRedisData("data:" + visitorId);
                            redisOperations.deleteRedisData("entry:" + visitorId);
                            redisOperations.deleteRedisData("connected:" + visitorId);
                            VisitorTimeOutEvent.delete(data);
                        });
                    //});
                    console.log("|connectToAgent | BotKit.js | PollingStarted |  ", visitorId);
                    getPendingMessages(visitorId, session.key, session.affinityToken);            
                    });
                });
            });
            }
            catch(err) {
                agentAvailable = false;
                console.log(err)
                delete userResponseDataMap[visitorId];
                delete _map[visitorId];
                console.error("connectToAgent | BotKit.js | Error while Creating Session |", visitorId, err);
                redisOperations.deleteRedisData("data:" + visitorId);
                redisOperations.deleteRedisData("entry:" + visitorId);
                redisOperations.deleteRedisData("connected:" + visitorId);
                VisitorTimeOutEvent.delete(data);
                sdk.clearAgentSession(data);
                data.message = LANGUAGE["AGENT_NOT_AVAILABLE_1"][currentLanguage];
                data.overrideMessagePayload = null;
                sdk.sendUserMessage(data).then(function () {
                    console.log("Sent user message.");
                    data.message = LANGUAGE["AGENT_NOT_AVAILABLE_2"][currentLanguage];
                    getChatHistoryAndCreateCase(visitorId, "With dealer", false).then(function (response) {
                        if (typeof response != 'undefined') {
                            console.log("Fetching the Case number: ", response.CaseNumber);
                            data.message = data.message.replace("CASE_NUMBER", response.CaseNumber);
                            sdk.sendUserMessage(data).then(function () {
                                console.log("Sent user message.");
    
                            }).catch(function (err) {
                                console.log(err);
                                return err;
                            });
                        }
                        redirectToWelcomeIntent(visitorId);
                    }).catch((err) => { console.log(err); });
    
                }).catch(function (err) {
                    console.log(err);
                    return err;
                });
            };
}

function getLink(botText){
    var matches = [];
    botText.replace(/[^<]*(<a href="([^"]+)"([^<]+)<\/a>)/g,function() {
        matches.push(Array.prototype.slice.call(arguments, 2, 3));
    });
    if(matches.length == 1){
        botText = botText + "(" + matches[0] + ")";
    }
    return botText;
}

function formatChatHistory(response) {
    var history = "";
    var messages = response.messages;
            for (var i = 0; i < messages.length ; i++) {
                var text;
                    if(messages[i].components[0].data && messages[i].components[0].data.text) {
                        text = messages[i].components[0].data.text;
                        var JSONobj = {};
                        if(IsJsonString(text)) {
                            JSONobj = JSON.parse(text);
                            if(JSONobj.payload && JSONobj.payload.text) {
                                text = JSONobj.payload.text;
                                if(JSONobj.payload.buttons) {
                                    text = text + " : ";
                                    for(var j=0; j<JSONobj.payload.buttons.length; j++) {
                                        text = text + "(" + (j+1) + ") " + JSONobj.payload.buttons[j].title + " ";
                                    }
                                }
                            }
                        }
                        if(JSONobj && JSONobj.payload && JSONobj.payload.template_type === "table") {
                            var titles = JSONobj.payload.text + " " + JSONobj.payload.columns + " ";
                            var elementStr = " ";
                            for(var iElement=0; iElement < JSONobj.payload.elements.length; iElement++) {
                                var elementObj = JSONobj.payload.elements[iElement];
                                for(var iValue=0; iValue < elementObj.Values.length; iValue++) {
                                    elementStr = elementStr + elementObj.Values[iValue];
                                }
                                elementStr = elementStr + ",";
                            }
                            history = history + "Bot : " + titles + elementStr +  "\n";
                        }
                        else if(JSONobj && JSONobj.payload && JSONobj.payload.template_type == "live_agent") {
                            history += " Expert : " + text + '\n';
                        }
                        else if(messages[i].type === "incoming") {
                            if (text.substring(0, 8) === "PAYLOAD_") {
                                if(LANGUAGE[text]) {
                                    text = LANGUAGE[text][currentLanguage];
                                }
                              }
                            history += " User : " + text + '\n';
                        }
                        else {
                            if(text.indexOf("href") >= 0) {
                                text = getLink(text);
                            }
                            history += " Bot : " + text + '\n';
                        }
                    }   
            }
            history = history.replace( /(<([^>]+)>)/ig, ' ');
            return history;
}

async function onUserMessage(requestId, data, cb) {
    var visitorId = _.get(data, 'channel.from');
    if (data.channel && !data.channel.channelInfos) {
        data.channel.channelInfos = {
            from: visitorId
        }
    }
    userDataMap[visitorId] = data;
    redisOperations.getRedisData("entry:" + visitorId).then(async function (entry) {
        if (data.message === "#session_closed" || data.message === "quit" || data.message === 'ophouden') {
            var res = await getChatHistoryAndCreateCase(visitorId, "New", true).catch((err) => {console.log(err);});
            redirectToWelcomeIntent(visitorId);
            closeAgentChat(data, entry, visitorId);
            return;
        }

        //Comment below line for sentinels.
        //entry = (typeof entry == 'undefined' || !entry)? _map[visitorId]: entry;

        if (entry) {
            console.log("|onUserMessage | BotKit.js | Entry |", visitorId);
            var session_key = entry.session_key;
            var affinity_token = entry.affinity_token;
            var message = {
                text: data.message
            }
            data.context.session_key = session_key;
            data.context.affinity_token = affinity_token;
            VisitorTimeOutEvent.add(data);

            return api.sendMsg(session_key, affinity_token, message).catch(function (err) {
                console.error("|onUserMessage | BotKit.js | Entry |", visitorId,err);
                clearAgentNotification(data, visitorId);
            })
        } else {
            sdk.clearAgentSession(data).then(function () {
                console.log("On_User_Msg", JSON.stringify(data.message));
                return sdk.sendBotMessage(data, cb);
            })
        }
    })
}

function onBotMessage(requestId, data, cb) {
    if (data.message.length === 0 || data.message === '') {
        return;
    }
    var visitorId = _.get(data, 'channel.from');
    redisOperations.getRedisData("entry:" + visitorId).then(function (entry) {
        // Comment below for sentinel architecture.
        // console.log("Inside on Bot Message: ", entry);
        // entry = (typeof entry == 'undefined' || entry.length == 0) ? _map[visitorId]:entry;
        // console.log("Entry after trasnformation.", entry);
        if(entry){
            var message_tone = _.get(data, 'context.message_tone');
            console.log("Message tone --->", message_tone);
            if (message_tone && message_tone.length > 0) {
                var angry = _.filter(message_tone, {
                    tone_name: 'angry'
                });
                if (angry.length) {
                    angry = angry[0];
                    console.log("--Angry Level  >>>>> ", angry.level);
                    if ((angry.level == 3 || angry.level > 3) && (data.context && data.context.intent != "Agent Chat")) {
                        console.log("|connectToAgent | BotKit.js | Angry Level Found |", visitorId);
                        data.message = "Agent Chat";
                        data.overrideMessagePayload = null;
                        return sdk.sendBotMessage(data);
                    } else {
                        sdk.sendUserMessage(data, cb);
                    }
                } else {
                    sdk.sendUserMessage(data, cb);
                }
            } else if (!entry) {
                sdk.sendUserMessage(data, cb);
            }
        }else {
            console.log("On_Bot_Msg", JSON.stringify(data.message));
            sdk.sendUserMessage(data, cb);
        }
    })
}

async function closeAgentChat(data, entry, visitorId) {
    try {
        if (entry) {
            var session_key = entry.session_key;
            var affinity_token = entry.affinity_token;
            await api.endChat(session_key, affinity_token);
        }
    }
    catch (error) {
        console.error("|closeAgentChat | BotKit.js |", error);
    }
    clearAgentNotification(data, visitorId);
}

function closeChat(data) {
    VisitorTimeOutEvent.delete(data);
    var visitorId = _.get(data, 'channel.channelInfos.from');
    if (!visitorId) {
        visitorId = _.get(data, 'channel.from');
    }
    redisOperations.deleteRedisData("entry:" + visitorId)
    redisOperations.deleteRedisData("data:" + visitorId)
    redisOperations.deleteRedisData("connected:" + visitorId)
    sdk.sendUserMessage(data).then(() => {
        sdk.clearAgentSession(data).then(() => {
            console.log("| closeChat | BotKit.js | ClearAgentSession |", visitorId);
        });
    })

}
function clearAgentNotification(data, visitorId) {
    console.log("|clearAgentNotification | BotKit.js |", visitorId);
    try {
        sdk.clearAgentSession(data);
        redisOperations.deleteRedisData("entry:" + visitorId);
        redisOperations.deleteRedisData("data:" + visitorId);
        redisOperations.deleteRedisData("connected:" + visitorId);
        data.message = messageConf.sessionClosedMsg;
        data.overrideMessagePayload = null;
        sdk.sendUserMessage(data);
    }
    catch (error) {
        console.error("|clearAgentNotification | BotKit.js |", error);
    }
}

async function getChatHistoryAndCreateCase(visitorId, status, agentAvailable) {
   return await getChatHistory(visitorId).then( async (history) => {
        history = formatChatHistory(history);
        if(useCase == "UC26") {
            if(!agentAvailable) {
                requestObjectForCase.category = "Part Enquiry";
                requestObjectForCase.subCategory = "Pricing";
            }
            else if(agentAvailable) {
                requestObjectForCase.category = "Missing price";
                requestObjectForCase.subCategory = "";
            }
        }
        var response = await api.getCaseAccessTokenAndCreateCase(history, status, requestObjectForCase);
        response = JSON.parse(response);
        return response;
        }).catch(function(err) {
        return Promise.reject(err);
      });
}

function redirectToWelcomeIntent(visitorId) {
    var data = userDataMap[visitorId];
    sdk.clearAgentSession(data);
    data.metaInfo = {
        "intentInfo": {
        "intent": "Main Menu Intent"}
    }
    var ObjectTypes = require("./lib/sdk/ObjectTypes");
    var ObjectType = ObjectTypes['OnMessagePayload'];
    // Flush outdated message to avoid sending it.
    data.message = "";
    sdk.resetBot(data).then(function() {
    console.log("Bot has been reset. Flushed context variables");
    console.log("Triggering Main Intent dialog.");
    sdk.sendBotMessage(new ObjectType(data.requestId, data.botId, data.componentId, data)).then(function() {
        console.log("Successfully called Main Intent.");
        return;
    }).catch(function(err) {
        console.log(err);
        return err;
    });
    }).catch(function(err) {
        console.log(err);
        return err;
    });
}

function parseISOString(s) {
    var b = s.split(/\D+/);
    return new Date(Date.UTC(b[0], --b[1], b[2], b[3], b[4], b[5], b[6]));
  }

function getChatHistory(visitorId, res) {
    var userId = visitorId;
    var data = userDataMap[userId];

    if (data) {
        var dateTo = parseISOString(dateFrom);
        dateTo = new Date(dateTo.getTime() + 10*60000);
        data.dateFrom = dateFrom;
        data.dateTo = dateTo.toISOString();
        return sdk.getMessages(data, function(err, resp) {
            if (err) {
                return err;
            }
            var messages = resp.messages;
            return messages;
        });
    } else {
        var error = {
            msg: "Invalid user",
            code: 401
        };
        return error;
    }
}

function onAgentTransfer(requestId, data, callback) {

    var visitorId = _.get(data, 'channel.channelInfos.from');
    if (!visitorId) {
        visitorId = _.get(data, 'channel.from');
    }
    connectToAgent(requestId, data, callback);
}

const IsJsonString = function(str) {
    try {
        JSON.parse(str);
    } catch (e) {
        return false;
    }
    return true;
}

async function shutdown(e) {
    /*Close redis database module*/
    try {
        redisOperations.closeConnection();
    }
    catch (e) {
        this.e = e;
        console.error("|shutdown | BotKit.js | Closing Redis connection Error|", e);
    }
    if (e) {
        process.exit(1); // Non-zero failure code
    } else {
        console.log("|shutdown | BotKit.js | Closing Redis connection success");
        process.exit(0);
    }
}

async function startup() {
    console.log("|startup | BotKit.js");
    console.log('|startup | BotKit.js | PID : ' + process.pid);
    restartPolling();
}

function restartPolling() {
    /*Restarting long Polling for all the active sessions*/
    console.log('|restartPolling | BotKit.js | ');
    redisOperations.getRedisKeys().then(function (keys) {
        console.log('|restartPolling | BotKit.js | Count ', keys.length);
        for (var i = 0; i < keys.length; i++) {
            redisOperations.getRedisData(keys[i]).then(function (data) {
                getPendingMessages(data.visitorId, data.session_key, data.affinity_token).then()
                    .catch(function (err) {
                        console.error('|restartPolling | BotKit.js | error while restarting polling for ', data.visitorId,err);
                    });
            });
        }
    });
}

startup();
process.on('SIGTERM', () => {
    console.log("|SIGTERM | BotKit.js");
    shutdown();
});

process.on('SIGINT', () => {
    console.log("|SIGINT | BotKit.js");
    shutdown();
});

process.on('uncaughtException', err => {
    console.error("|uncaughtException | BotKit.js |", err);
});

module.exports = {
    botId: botId,

    on_user_message: function(requestId, data, callback) {
        console.log("data on user message", JSON.stringify(data.message));


        var channelType = _.get(data, 'channel.type');
        var streamId =  _.get(data, 'context.session.opts.streamId');
        onUserMessage(requestId, data, callback);
    },
    on_bot_message: function(requestId, data, callback) {

        console.log("data on bot message", JSON.stringify(data.message));
       onBotMessage(requestId, data, callback);
    },
    on_agent_transfer: function(requestId, data, callback) {
        var visitorId = _.get(data, 'channel.channelInfos.from');
        if (!visitorId) {
            visitorId = _.get(data, 'channel.from');
        }
        console.log("data on agent transfer", JSON.stringify(data.message));
        connectToAgent(requestId, data, callback);
    },
    on_event: function(requestId, data, callback) {
        console.log("on_event -->  Event : ", data.event, data.context.intent);
        return callback(null, data);
    },
       gethistory: function(req, res) {
        var userId = req.query.userId;
        return redisOperations.getRedisData("data:"+userId)
        .then(function(data)
        {console.log("Function get history called");
        res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        res.setHeader("Pragma", "no-cache"); 
        res.setHeader("Expires", "0");

        if (data) {
            data.limit = 20; //max i suppose
            return sdk.getMessages(data, function(err, resp) {
                if (err) {
                    res.status(400);
                    return res.json(err);
                }
                var messages = resp.messages;
                res.status(200);
                return res.json(messages);
            });
        } else {
            var error = {
                msg: "Invalid user",
                code: 401
            };
            res.status(401);
            return res.json(error);
        }
    })
    }
};

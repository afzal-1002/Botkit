require("console-stamp")(console, { pattern: "dd/mm/yyyy HH:MM:ss.l", });
var config = require("./config.json");
var botId = Object.keys(config.credentials);
var botName = Object.keys(config.credentials);
var sdk = require("./lib/sdk");
var Promise = require("bluebird");
var api = require("./salesforceLiveChatAPI.js");
var _ = require("lodash");
var schedular = require("node-schedule");
var debug = require("debug")("Agent");
var messageConf = require("./messages.json");
var redisOperations = require("./lib/redisOperations");
var redisClient = require("./lib/RedisClient.js").createClient(config.redis);
var VisitorTimeOutEvent = require("./VisitorTimeOutEvent.js");
var utils = require("./utils");
const { resolve } = require("bluebird");
var sfdcConfig = require(config.sfdc_config_file);
var moment = require("moment-timezone");
var callCount = 0;
var axios = require("axios");
const { css } = require("jquery");

var Promise = require("bluebird");
var request = require("request-promise");
var _ = require("lodash");


async function getPendingMessages(visitorId, session_key, affinity_token, count = 1) {
  try {
      let lp = await redisOperations.get("longpoll:" + visitorId);
      console.log(new Date(), "incrValue in scheduler ", lp);
      
      if (lp === "0" || lp === 0 || !lp) {
          let incrValue = await redisOperations.incrRedisData(visitorId);
          console.log(new Date(), visitorId, "longpoll key -- ", incrValue);

          if (incrValue === 1 || incrValue === "1") {
              console.log("Polling initiated>>>>>>>>>>>>");
              count = count || 1;
              console.log("|getPendingMessages | BotKit.js | Count :" + count + "|" + visitorId);

              let endChat = false;
              let agentClosed = false;
              let data = await redisOperations.getRedisData("data:" + visitorId);
              
              if (!data) {
                  console.log("|getPendingMessages | BotKit.js | Data not found | " + visitorId);
                  return;
              }
              
              try {
                  let res = await backoffRetry(() => api.getPendingMessages(session_key, affinity_token));
                  
                  for (const [key, event] of Object.entries(res.messages || {})) {
                      switch (event.type) {
                          case "ChatEstablished":
                              console.log("|getPendingMessages | BotKit.js | ChatEstablished | " + visitorId);
                              await redisOperations.insertRedisData(visitorId, 0);
                              let timeout = event.message.chasitorIdleTimeout.timeout;
                              data.context.session_key = session_key;
                              data.context.affinity_token = affinity_token;
                              VisitorTimeOutEvent.add(data, timeout);
                              break;
                          
                          case "ChatMessage":
                              console.log("|getPendingMessages | BotKit.js | ChatMessage (FromAgent) | " + visitorId);
                              await redisOperations.insertRedisData(visitorId, 0);
                              data.message = event.message.text;
                              let initials = (event.message.name.match(/\b\w/g) || []).join('').toUpperCase();
                              console.log("agent_name", initials);
                              data.overrideMessagePayload = {
                                  body: JSON.stringify({
                                      type: "template",
                                      payload: {
                                          template_type: "live_agent",
                                          subText: "Agent_" + initials,
                                          text: event.message.text,
                                          agent_name: initials,
                                      },
                                  }),
                                  isTemplate: true,
                              };
                              let interval = key >= 1 ? 1000 * key : 0;
                              setTimeout(() => sdk.sendUserMessage(data).catch(console.error), interval);
                              break;
                          
                          case "ChatEnded":
                              endChat = true;
                              await clearSessionData(visitorId, data);
                              data.message = messageConf.chatEndedMsg;
                              return sdk.sendUserMessage(data);
                              
                          case "ChatRequestFail":
                              console.log("|getPendingMessages | BotKit.js | ChatRequestFail | ", visitorId);
                              endChat = true;
                              await clearSessionData(visitorId, data);
                              data.message = messageConf.WhenAgentIsBusy;
                              return sdk.sendUserMessage(data, () => {
                                  data.metaInfo = { nlMeta: { isRefresh: true, intent: "Subsequentwaitflow" } };
                                  data.message = "Subsequentwaitflow";
                                  return sdk.sendBotMessage(data);
                              });
                      }
                  }
              } catch (error) {
                  console.error("|getPendingMessages | BotKit.js | ERROR From getMessages Api |", error);
                  if (error.statusCode === 403) {
                      await redisOperations.insertRedisData(visitorId, 0);
                      console.info("|getPendingMessages | BotKit.js | Removing Expired Session from Redis |", visitorId);
                      await clearAgentNotification(data, visitorId);
                  }
              }
              
              if (!endChat) {
                  redisOperations.insertRedisData(visitorId, 0);
                  if (count <= 50) {
                      setTimeout(() => getPendingMessages(visitorId, session_key, affinity_token, count + 1), 1000);
                  } else {
                      console.warn(`Polling stopped: exceeded max retries (${count}) for ${visitorId}`);
                  }
              }
          }
      } else {
          await clearSessionData(visitorId, await redisOperations.getRedisData("data:" + visitorId));
      }
  } catch (error) {
      console.error("|getPendingMessages | BotKit.js | ERROR |", error);
  }
}

async function clearSessionData(visitorId, data) {
  if (!data) return;
  VisitorTimeOutEvent.delete(data);
  let keys = ["longpoll", "entry", "data", "connected"].map(k => `${k}:${visitorId}`);
  await redisOperations.deleteRedisData(...keys);
  sdk.clearAgentSession(data);
  console.log("|getPendingMessages | BotKit.js | ChatEnded |", visitorId);
}

async function backoffRetry(fn, delay = 1000, maxRetries = 5) {
  try {
      return await fn();
  } catch (err) {
      if (maxRetries > 0) {
          await sleep(delay);
          return backoffRetry(fn, delay * 2, maxRetries - 1);
      }
      throw err;
  }
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}


function gethistory(req, res) {
  var userId = req.query.userId;
  var sessionId = req.query.sessionId;
  console.log(sessionId + "############# " + userId);
  return redisOperations.getRedisData("data:" + userId).then(function (data) {
    res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    res.setHeader("Pragma", "no-cache");
    res.setHeader("Expires", "0");

    if (data) {
      data.skip = 0;
      data.sessionId = sessionId;
      data.baseUrl = `https://bots.kore.ai/api/public/bot/${config.credentials.botId}`;
      return sdk.getMessages(data, function (err, resp) {
        if (err) {
          res.status(400);
          return res.json(err);
        }
        data.skip = 100;
        var messages = resp.messages;
        console.log("Messages1", messages.length);

        if (messages.length == 100) {
          sdk.getMessages(data, function (err, resp) {
            if (err) {
              res.status(400);
              return res.json(err);
            }
         
            if (resp.messages.length) {
              messages.push(...resp.messages);
            }
            console.log("Messages2", messages.length);
            res.status(200);
            return res.json(messages);
          })
        } else {
          res.status(200);
          return res.json(messages);
        }

      });
    } else if (!data) {
      const data = {
        skip: 0,
        sessionId: sessionId,
        userId: userId,
        baseUrl: `https://bots.kore.ai/api/public/bot/${config.credentials.botId}`,
      };
      return sdk.getMessages(data, function (err, resp) {
        if (err) {
          res.status(400);
          return res.json(err);
        }
        data.skip = 100;
        var messages = resp.messages;
        console.log("Messages1", messages.length);
        if (messages.length == 100) {
          sdk.getMessages(data, function (err, resp) {
            if (err) {
              res.status(400);
              return res.json(err);
            }
            // console.log("ouside if",resp.messages.length);
            if (resp.messages.length) {
              //   console.log("inside if");
              messages.push(...resp.messages);
            }
            console.log("Messages2", messages.length);
            res.status(200);
            return res.json(messages);
          })
        } else {
          res.status(200);
          return res.json(messages);
        }


      });
    } else {
      var error = {
        msg: "Invalid user",
        code: 401,
      };
      res.status(401);
      return res.json(error);
    }
  });
}


async function connectToAgent(requestId, data, cb) {
  var visitorId = _.get(data, "channel.channelInfos.from");
  if (!visitorId) {
    visitorId = _.get(data, "channel.from");
  }
  console.log("|connectToAgent | BotKit.js |", visitorId);

  redisOperations.updateRedisWithUserData(visitorId, data).then(function () {

    console.log("|connectToAgent | BotKit.js | updateRedisWithUserData |", visitorId);
    redisOperations.insertRedisData(visitorId, 0);
    redisOperations.setTtl("data", visitorId);
  });

  try {
    const session = await api.getSession();
    var customData = "";
    var options = customData || {};

    var buttonId = sfdcConfig.live_agent.buttonId;
    options.VisitorName = "visitor";
    options.buttonId = buttonId;
    console.log("|connectToAgent | BotKit.js | Request for initChat | buttonId", buttonId)
    console.log("|connectToAgent | BotKit.js | Request for initChat | visitorId ", visitorId, "|", options.uri);
    await api.initChat(session, options, data);
    var redisEntry = {
      session_key: session.key,
      affinity_token: session.affinityToken,
      visitorId: visitorId,
    };
    redisOperations.updateRedisWithEntry(visitorId, redisEntry).then(function () {
      console.log("|connectToAgent | BotKit.js | updateRedisWithEntry |", visitorId);
      redisOperations.setTtl("entry", visitorId);
      var connectToAgent = { server: 1, time: new Date() };

      redisOperations.updateRedisConnectedAgent(visitorId, connectToAgent).then(async function () {
        redisOperations.setTtl("connected", visitorId);
        data.context.session_key = session.key;
        data.context.affinity_token = session.affinityToken;
        VisitorTimeOutEvent.add(data);


        /* Agent Message Before Chat is being initiated*/
        var linkUrl = config.app.url + config.app.apiPrefix + "/korebotkit/history/index.html?sessionId=" + data.context.session.BotUserSession.conversationSessionId + "&visitorId=" + visitorId;
        var historyTags =
          data.context.historicTags &&
            data.context.historicTags[0] &&
            data.context.historicTags[0].tags
            ? data.context.historicTags[0].tags.join("\n")
            : "";
        var lastMessage = _.get(data, "context.session.BotUserSession.lastMessage.messagePayload.message.body", "");
        var message = {text: "Hi, a user needs help.\nChat history : " + linkUrl + "\nHistory tags : " + historyTags };
        const systemMesage = await api.getPendingMessages(session.key, session.affinityToken);
        systemMesage.messages.forEach(async (ele) => {
          if (ele.type === "ChatRequestFail") {

            VisitorTimeOutEvent.delete(data);
            console.log("|getPendingMessages | BotKit.js | ChatRequestFail | ", visitorId, ele.type);
            redisOperations.deleteRedisData("longpoll:" + visitorId);
            redisOperations.deleteRedisData("entry:" + visitorId);
            redisOperations.deleteRedisData("data:" + visitorId);
            redisOperations.deleteRedisData("connected:" + visitorId);
            endChat = true;
            sdk.clearAgentSession(data);
            
            var triggerIntent = {
              'nlMeta': {
                'isRefresh': true,
                'intent': "LiveAgentDisconnected"
              }
            }
            data["metaInfo"] = triggerIntent;
            data.message = "LiveAgentDisconnected";
            setTimeout(() => {
              return sdk.sendBotMessage(data);
            }, 3000);


          } else if (ele.type === "ChatRequestSuccess") { 
            console.log("**********" + data.context.session.BotUserSession.agentAvailable)
            systemMesage.messages[0].message.estimatedWaitTime
            var estimatedWaitTime = ''
            var queuePosition = ''
            var agentAssistMessage = ''
            var minutes = ''
            var minutesText = ''
            if (systemMesage !== undefined && systemMesage.messages[0] !== undefined && systemMesage.messages[0].message !== undefined
              && systemMesage.messages[0].message.estimatedWaitTime !== undefined) {
              estimatedWaitTime = systemMesage.messages[0].message.estimatedWaitTime
              var minutes = Math.floor(estimatedWaitTime / 60) + 1;
              if (minutes < 0) { minutesText = "less than a minute" }
              if (minutes = 1) { minutesText = "about 1 minute" }
              if (minutes > 1) {minutesText = "about " + minutes + " minutes" }

            }
            if (systemMesage !== undefined && systemMesage.messages[0] !== undefined && systemMesage.messages[0].message !== undefined
              && systemMesage.messages[0].message.queuePosition !== undefined) {
              queuePosition = systemMesage.messages[0].message.queuePosition
            }
            if (queuePosition !== undefined && estimatedWaitTime !== undefined) {
              const toOrdinalSuffix = num => {
                const int = parseInt(num),
                  digits = [int % 10, int % 100],
                  oPattern = [1, 2, 3, 4],
                  tPattern = [11, 12, 13, 14, 15, 16, 17, 18, 19];
                return oPattern.includes(digits[0]) && !tPattern.includes(digits[1])
                ? int 
                : int 
              };

              agentAssistMessage = "One of our representatives will be with you shortly.\n"+"~You are number " + toOrdinalSuffix(queuePosition) + " in the queue." + "~Cancel chat request\n"+"\n\n~If you use this service, the contents of your chat will be processed in accordance to [Salesforce's Privacy Notice](https://help.salesforce.com/s/?language=en_US).\n\n *Please do not* provide sensitive personal information (such as financial or health information) in the chatbot.";
            
            }
            else {
              agentAssistMessage = "One of our representatives will be with you shortly.\n"+"~You are number " + toOrdinalSuffix(queuePosition) + " in the queue." + "~Cancel chat request\n"+"\n\n~If you use this service, the contents of your chat will be processed in accordance to [Salesforce's Privacy Notice](https://help.salesforce.com/s/?language=en_US). \n\n *Please do not* provide sensitive personal information (such as financial or health information) in the chatbot."
            }
            data.message = agentAssistMessage
            data.overrideMessagePayload = null;
            const responseSendAPI = await api.sendMsg(session.key, session.affinityToken, message).catch(function (err) {
              console.error("connectToAgent | BotKit.js | Error while Sending Transcript |", visitorId,
                err);
              redisOperations.deleteRedisData("longpoll:" + visitorId); //added
              redisOperations.deleteRedisData("data:" + visitorId);
              redisOperations.deleteRedisData("entry:" + visitorId);
              redisOperations.deleteRedisData("connected:" + visitorId);
              VisitorTimeOutEvent.delete(data);
            });
            console.log(`********${responseSendAPI}**************`);
            console.log("ChatRequestSuccess")
            checkConnection(1, session, visitorId, data);
            data.context.session_key = session.key;
            data.context.affinity_token = session.affinityToken;
            VisitorTimeOutEvent.add(data);
            // sdk.sendUserMessage(data);

            var agentAssistMessageArr=data.message.split("~");
            for (let i = 0; i < agentAssistMessageArr.length; i++) {
              console.log("Agent Message---"+agentAssistMessageArr[i])
              setTimeout(function() {
                let message = agentAssistMessageArr[i];
                
                if(i==2){
                  // var mycustomMessage="{\"type\":\"template\",\"payload\":{\"template_type\":\"button\",\"text\":\"\",,\"subText\":\"\close_chat\",\"buttons\":[{\"type\":\"postback\",\"title\":\"Close Chat\",\"payload\":\"end chat\"}]}}";
                  var mycustomMessage="{\"type\":\"template\", \"payload\":{\"template_type\":\"quick_replies\",\"subText\" : \"cancel_chat\", \"quick_replies\": [{ \"content_type\":\"text\", \"title\":\"Cancel chat request\", \"payload\":\"end chat\"}]}}";
                  data.overrideMessagePayload={
                   body: mycustomMessage,
                   isTemplate: true
                    }
                  data.message =  mycustomMessage  ; 
                  sdk.sendUserMessage(data);    
                }else{
                  data.message = botId+"-"+i  + "| \n" +message;
                  data.overrideMessagePayload = null;
                  sdk.sendUserMessage(data);
                }


                             
              }, (i + 1) * 500);
            }




          }
        });
      });
    });
  } catch (err) {
    console.error(
      "connectToAgent | BotKit.js | Error while Creating Session |",
      visitorId,
      err
    );
    redisOperations.deleteRedisData("longpoll:" + visitorId);
    redisOperations.deleteRedisData("data:" + visitorId);
    redisOperations.deleteRedisData("entry:" + visitorId);
    redisOperations.deleteRedisData("connected:" + visitorId);
    VisitorTimeOutEvent.delete(data);
    sdk.clearAgentSession(data);
    console.log("| closeChat | BotKit.js | ClearAgentSession |", visitorId);
    data.message = messageConf.ApifailMsg;
    data.overrideMessagePayload = null;
    return sdk.sendUserMessage(data);

  }
}






async function checkConnection(count, session, visitorId, data) {

  //let value = false
  try {
    api.getPendingMessages(session.key, session.affinityToken).then(async (res) => {
      // console.log("Count " + count + JSON.stringify(res));
      var eventType = JSON.parse(JSON.stringify(res));
      // console.log("type",eventType.messages[0].type);
      if (!res.messages.length) {
        //  console.log("inside checkConnection if condition ");
        if (count === 7) {
          VisitorTimeOutEvent.delete(data);
          //redisOperations.insertRedisData(visitorId, 0)
          console.log("|getPendingMessages | BotKit.js | ChatRequestFail | ", visitorId, res.messages.type);
          redisOperations.deleteRedisData("longpoll:" + visitorId);
          redisOperations.deleteRedisData("entry:" + visitorId);
          redisOperations.deleteRedisData("data:" + visitorId);
          redisOperations.deleteRedisData("connected:" + visitorId);
          //endChat = true;
          sdk.clearAgentSession(data);
          console.log("| closeChat | BotKit.js | ClearAgentSession |", visitorId);
          //data.message = messageConf.WhenAgentIsBusy;
          data.overrideMessagePayload = null;
          data.message = messageConf.WhenAgentIsBusy;
          sdk.sendUserMessage(data, function () {
            var intentContinuewaiting = {
              'nlMeta': {
                'isRefresh': true,
                'intent': "Subsequentwaitflow"
              }
            }
            data["metaInfo"] = intentContinuewaiting;
            data.message = "Subsequentwaitflow";
             console.log("message",data.message);
            return sdk.sendBotMessage(data);
          });
        } else {
          count++;
          checkConnection(count, session, visitorId, data);
        }
      } else if (eventType.messages[0].type == "ChatRequestFail") {
        // redisOperations.insertRedisData(visitorId, 0);
        VisitorTimeOutEvent.delete(data);
        console.log("|getPendingMessages | BotKit.js | ChatRequestFail | ", visitorId, eventType.messages[0].type);
        redisOperations.deleteRedisData("longpoll:" + visitorId);
        redisOperations.deleteRedisData("entry:" + visitorId);
        redisOperations.deleteRedisData("data:" + visitorId);
        redisOperations.deleteRedisData("connected:" + visitorId);
        // endChat = true;
        sdk.clearAgentSession(data);
        console.log("| closeChat | BotKit.js | ClearAgentSession |", visitorId);
        // console.log("initial chat failed");
        data.message = messageConf.WhenAgentIsBusy;
        data.overrideMessagePayload = null;
        //return sdk.sendUserMessage(data);
        sdk.sendUserMessage(data, function () {
          var intentContinuewaiting = {
            'nlMeta': {
              'isRefresh': true,
              'intent': "Subsequentwaitflow"
            }
          }
          data["metaInfo"] = intentContinuewaiting;
          data.message = "Subsequentwaitflow";
          //  console.log("message",data.message);
          return sdk.sendBotMessage(data);
        });
      }
      else {
        //value = true
        redisOperations.insertRedisData(visitorId, 0);
        var timeout;
        data.context.session_key = session.key;
        data.context.affinity_token = session.affinityToken;
        VisitorTimeOutEvent.add(data, timeout);
        //console.log("cond " + cond);
        console.log( "|getPendingMessages | BotKit.js | ChatEstablished | ", visitorId );
        console.log( "|connectToAgent | BotKit.js | PollingStarted |  ", visitorId );
        getPendingMessages(visitorId, session.key, session.affinityToken);
        // return value
      }
    });
  } catch (error) {
    console.log("error || checkConnection || Botkit.js" + error);
  }
}



function onBotMessage(requestId, Botdata, cb) {
  // bot_message = data.message;
  var context = Botdata.context;
  if (Botdata.message === config.sendMailConf.sessionTimeoutMsg) {
    var visitorId = _.get(Botdata, "channel.from");
    if (Botdata.channel && !Botdata.channel.channelInfos) {
      Botdata.channel.channelInfos = { from: visitorId, };
    }
    console.log("On Bot Message visitorId: " + visitorId);
    redisOperations.getRedisData("emailsent:" + visitorId).then(async function (emailsent) {
      if (!emailsent) {
        emailsent = false;
        console.log("On Bot Message emailsent set to false: " + emailsent, " ", visitorId);
      }
      if (emailsent == false) {
        sdk.sendUserMessage(Botdata, cb);
        if (context.session.BotUserSession.AccountExist) {
          var email = context.session.BotUserSession.email;
          var contactsemail = context.session.BotUserSession.emailArray;
          var firstName = context.session.BotUserSession.firstName;
          var lastName = context.session.BotUserSession.lastName;
          var sessionId = context.session.BotUserSession.conversationSessionId;
          var visitorId = context.session.UserContext._id;
          var referenceNumber = context.session.BotUserSession.ccReferenceNumber;
          var data = JSON.stringify({
            sessionId: sessionId,
            visitorId: visitorId,
            name: firstName + " " + lastName,
            email: email,
            contactsemail: contactsemail,
            referenceNumber: referenceNumber
          });
          var API_config = {
            method: "post",
            url: config.app.url + config.app.apiPrefix + "/sendMail",
            headers: {
              "Content-Type": "application/json",
            },
            data: data,
          };
          context.session.BotUserSession.emailsent = true;
          context.session.BotUserSession.emailArray = null;
          axios(API_config)
            .then(function (response) {

            })
            .catch(function (error) {
              console.log(error);
            });
        }
      }
    })
  } else if (context.session.BotUserSession.isUserOwner == true) {


    var email = context.session.BotUserSession.ownerEmail;
    var registrationAccountNumber = context.session.BotUserSession.accountNumber;
    //var contactsemail = context.session.BotUserSession.emailArray;
    var firstName = context.session.BotUserSession.firstName;
    var lastName = context.session.BotUserSession.lastName;

    var data = JSON.stringify({
      registrationName: firstName + " " + lastName,
      registrationEmail: email,
      registrationAccountNumber: registrationAccountNumber
    });
    var API_config = {
      method: "post",
      url: config.app.url + config.app.apiPrefix + "/RegistrationsendMail",
      headers: {
        "Content-Type": "application/json",
      },
      data: data,
    };
    axios(API_config)
      .then(function (response) {
        // console.log(JSON.stringify(response.data));
      })
      .catch(function (error) {
        console.log(error);
      });
    context.session.BotUserSession.isUserOwner = false;
    sdk.sendUserMessage(Botdata, cb);
  } else if (context.session.BotUserSession.Retrieveinvoice == true) {
    var visitorId = _.get(Botdata, "channel.channelInfos.from");
    if (!visitorId) {
      visitorId = _.get(Botdata, "channel.from");
    }
    var InvoiceMessageDate = new Date(Botdata.context.updatedOn);
    var InvoiceMessageMillisecondnew = InvoiceMessageDate.getTime();
    redisOperations.updateRedisWithInvoiceMessageDateTime(visitorId, InvoiceMessageMillisecondnew).then(function () {
      console.log("|connectToAgent | BotKit.js | updateRedisWithInvoiceMessageDateTime |", InvoiceMessageMillisecondnew, visitorId);
      redisOperations.setTtl("InvoiceMessageMillisecondnew", visitorId);
    });
    if (context.session.BotUserSession.Retrieveinvoice == true && Botdata.message.includes("Is there anything else I can do for you?")) {
      var InvoiceMessageDate = new Date(Botdata.context.updatedOn);
      var InvoiceMessageMillisecond = InvoiceMessageDate.getTime();
      console.log("botdata", InvoiceMessageMillisecond);
      setTimeout(function () {
        redisOperations.getRedisData("InvoiceMessageMillisecondnew:" + visitorId).then(async function (InvoiceMessageMillisecondnew) {
          console.log("InvoiceMessageMillisecondnew", InvoiceMessageMillisecondnew);
          if (InvoiceMessageMillisecondnew === InvoiceMessageMillisecond) {
            context.session.BotUserSession.Retrieveinvoice = false;
            sdk.clearConversationSession(Botdata, cb);
          }
        })
      }, config.getPDF.InvoiceDownloadTimeOut);
      sdk.sendUserMessage(Botdata, cb);
    } else {
      context.session.BotUserSession.Retrieveinvoice = false;
      sdk.sendUserMessage(Botdata, cb);
    }
  }
  else if (Botdata.message === config.AddressForm.skipMessage) {
    sdk.skipUserMessage(Botdata, cb);
  }
  else {
    sdk.sendUserMessage(Botdata, cb);
  }

}

function onUserMessage(requestId, data, cb) {
  console.log("On User Message", data.message);

  var visitorId = _.get(data, "channel.from");
  if (data.channel && !data.channel.channelInfos) {
    data.channel.channelInfos = { from: visitorId, };
  }
  redisOperations.getRedisData("entry:" + visitorId).then(async function (entry) {
    if (entry) {
      if (
        data.message === "#session_closed" ||
        data.message === "quit" ||
        data.message === "Quit" ||
        data.message === "QUIT" ||
        data.message === "ophouden" ||
        data.message === "end chat" ||
        data.message === "End chat" ||
        data.message === "End Chat" ||
        data.message === "end Chat" ||
        data.message === "discard" ||
        data.message === "Discard" ||
        data.message === "ophouden"
      ) {
        closeAgentChat(data, entry, visitorId);
      }
    }

    if (entry) {
      console.log("|onUserMessage | BotKit.js | Entry |", visitorId, entry);

      var session_key = entry.session_key;
      var affinity_token = entry.affinity_token;
      var message = {
        text: data.message,
      };
      data.context.session_key = session_key;
      data.context.affinity_token = affinity_token;
      VisitorTimeOutEvent.add(data);

      return api
        .sendMsg(session_key, affinity_token, message)
        .catch(function (err) {
          console.error( "|onUserMessage | BotKit.js | Entry |" + visitorId + " Error" + err );
          clearAgentNotification(data, visitorId);
        });
    } else {
      sdk.clearAgentSession(data).then(function () {
        return sdk.sendBotMessage(data, cb);
      });
    }
  });
}
async function closeAgentChat(data, entry, visitorId) {
  try {
    if (entry) {
      //   console.log("Entry",entry);
      var session_key = entry.session_key;
      var affinity_token = entry.affinity_token;
      await api.endChat(session_key, affinity_token);

    }
  } catch (error) {
    console.error("|closeAgentChat | BotKit.js |", error);
    data.message = messageConf.ApifailMsg;
    data.overrideMessagePayload = null;
    sdk.sendUserMessage(data);
  }
  VisitorTimeOutEvent.delete(data);
  //console.log("Entry",entry);
  clearAgentNotification(data, visitorId);
}
function closeChat(data) {
  VisitorTimeOutEvent.delete(data);
  var visitorId = _.get(data, "channel.channelInfos.from");
  if (!visitorId) {
    visitorId = _.get(data, "channel.from");
  }
  redisOperations.deleteRedisData("longpoll:" + visitorId);
  redisOperations.deleteRedisData("entry:" + visitorId);
  redisOperations.deleteRedisData("data:" + visitorId);
  redisOperations.deleteRedisData("connected:" + visitorId);
  sdk.sendUserMessage(data).then(() => {
    sdk.clearAgentSession(data).then(() => {
      console.log("| closeChat | BotKit.js | ClearAgentSession |", visitorId);
    });
  });
}
function clearAgentNotification(data, visitorId) {
  console.log("|clearAgentNotification | BotKit.js |", visitorId);
  try {
    sdk.clearAgentSession(data);
    redisOperations.deleteRedisData("longpoll:" + visitorId);
    redisOperations.deleteRedisData("entry:" + visitorId);
    redisOperations.deleteRedisData("data:" + visitorId);
    redisOperations.deleteRedisData("connected:" + visitorId);
    data.message = messageConf.sessionClosedMsg;
    data.overrideMessagePayload = null;
    sdk.sendUserMessage(data);
  } catch (error) {
    console.error("|clearAgentNotification | BotKit.js |", error);
  }
}

function onAgentTransfer(requestId, data, callback) {
  var visitorId = _.get(data, "channel.channelInfos.from");
  if (!visitorId) {
    visitorId = _.get(data, "channel.from");
  }
  connectToAgent(requestId, data, callback);
}


async function shutdown(e) {
  /*Close redis database module*/
  try {
    redisOperations.closeConnection();
  } catch (error) {
    this.error = error;
    console.error("|shutdown | BotKit.js | Closing Redis connection Error|" , error);
  }
  if (error) {
    process.exit(1);
  } else {
    console.log("|shutdown | BotKit.js | Closing Redis connection success");
    process.exit(0);
  }
}

async function startup() {
  console.log("|startup | BotKit.js");
  console.log("|startup | BotKit.js | PID : " + process.pid);
  restartPolling();
}

function restartPolling() {
  /*Restarting long Polling for all the active sessions*/
  console.log("|restartPolling | BotKit.js | ");
  redisOperations.getRedisKeys().then(function (keys) {
    console.log("|restartPolling | BotKit.js | Count ", keys.length);
    for (var i = 0; i < keys.length; i++) {
      redisOperations.getRedisData(keys[i]).then(function (data) {
        getPendingMessages(
          data.visitorId,
          data.session_key,
          data.affinity_token
        )
          .then()
          .catch(function (err) {
            console.log("###########" + JSON.stringify(err));
            console.error( "|restartPolling | BotKit.js | error while restarting polling for " + data.visitorId +  err );
          });
      });
    }
  });
}

startup();
process.on("SIGTERM", () => {
  console.log("|SIGTERM | BotKit.js");
  shutdown();
});

process.on("SIGINT", () => {
  console.log("|SIGINT | BotKit.js");
  shutdown();
});

process.on("uncaughtException", (err) => {
  console.error("|uncaughtException | BotKit.js |"  + err);
});


module.exports = {
  botId: botId,
  botName: botName,

  on_user_message: function (requestId, data, callback) {
    debug("on_user_message");
    // sdk.clearAgentSession(data);
    onUserMessage(requestId, data, callback);
  },
  on_bot_message: function (requestId, data, callback) {
    debug("on_bot_message");
    if(data.message !== undefined && data.metaInfo && data.metaInfo.matchedIntentType)
    {
       console.log('I am under metainfo')
       console.log(data.metaInfo.matchedIntentType);

       if(data.metaInfo.matchedIntentType == 'Retry_Intent')
       {
            console.log('I am under small talk retryintent')
            data.message="I'd be happy to help you. What's your specific question?";
           return sdk.sendUserMessage(data, callback);
       }
       else if(data.metaInfo.matchedIntentType == 'help')
       {
           console.log("help");
           data.metaInfo = {
               intentInfo: {
                   intent: "Availability"
               }
           };
           console.log("help end");
           return sdk.sendBotMessage(data, callback);
          // return sdk.sendUserMessage(data, callback);
       }
       else
       {
           data.metaInfo = {
               intentInfo: {
                   intent: "Availability"
               }
           };
           console.log("Final else");
           return sdk.sendUserMessage(data, callback);
       }
       console.log("On User Message End "+ data.message);
       return sdk.sendUserMessage(data, callback);
   }
    onBotMessage(requestId, data, callback);
  },
  on_agent_transfer: function (requestId, data, callback) { onAgentTransfer(requestId, data, callback); },
  on_client_event: function (requestId, data, callback) {

    //console.log("data"+JSON.stringify(data)+"requestId"+requestId+"callback"+callback);
    var context = data.context;
    var visitorId = _.get(data, "channel.from");
    if (data.channel && !data.channel.channelInfos) {
      data.channel.channelInfos = { from: visitorId, };
    }
    redisOperations.getRedisData("entry:" + visitorId).then(async function (entry) {
      if (entry) {
        closeAgentChat(data, entry, visitorId);
        console.log("closechat triggred");
      }
    })
    if (context.session.BotUserSession.AccountExist) {
      var emailsent = context.session.BotUserSession.emailsent;
      console.log("on Client Event: emailsent ", emailsent, " ", visitorId);
      redisOperations.updateRedisWithUserDataEmailSent(visitorId, emailsent).then(function () {
        console.log("|connectToAgent | BotKit.js | updateRedisWithUserDataEmailSent |", emailsent, visitorId);
        redisOperations.setTtl("emailsent", visitorId);
      });
      if (emailsent == false) {
        var email = context.session.BotUserSession.email;
        var contactsemail = context.session.BotUserSession.emailArray;
        var firstName = context.session.BotUserSession.firstName;
        var lastName = context.session.BotUserSession.lastName;
        var sessionId = context.session.BotUserSession.conversationSessionId;
        var visitorId = context.session.UserContext._id;
        var referenceNumber = context.session.BotUserSession.ccReferenceNumber;
        var sendmaildata = JSON.stringify({
          sessionId: sessionId,
          visitorId: visitorId,
          name: firstName + " " + lastName,
          email: email,
          contactsemail: contactsemail,
          referenceNumber: referenceNumber
        });
        var API_config = {
          method: "post",
          url: config.app.url + config.app.apiPrefix + "/sendMail",
          headers: {
            "Content-Type": "application/json",
          },
          data: sendmaildata,
        };
        context.session.BotUserSession.emailArray = null;
        axios(API_config)
          .then(function (response) {
            emailsent = true;
            redisOperations.updateRedisWithUserDataEmailSent(visitorId, emailsent).then(function () {
              console.log("|connectToAgent | BotKit.js | updateRedisWithUserDataEmailSent | after emailsent", emailsent, visitorId);
              redisOperations.setTtl("emailsent", visitorId);
            });
          })
          .catch(function (error) {
            console.log(error);
          });
      }
    }
    return callback(null, data);
  },
  on_event: function (requestId, data, callback) {
    // console.log("data " + JSON.stringify(data));
    console.log( "|on_event | BotKit.js | event |",
      data.event,
      data.context.intent
    );
    return callback(null, data);
  },
  gethistory: gethistory,
};

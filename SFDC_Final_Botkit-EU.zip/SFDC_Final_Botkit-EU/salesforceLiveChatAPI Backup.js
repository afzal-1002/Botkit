var Promise = require("bluebird");
var request = require("request-promise");
var _ = require("lodash");

//loading config files
var sfdc_config_file = require("./config.json").sfdc_config_file;
var config = require(sfdc_config_file);
var liveAgentUrl = config.live_agent.liveAgentUrl;
var buttonId = config.live_agent.buttonId;
var apiVersion = config.live_agent.apiVersion;
var screenResolution = config.live_agent.screenResolution;
var language = config.live_agent.language;

async function getAvailability() {
  return new Promise(async (resolve, reject) => {
    var url =
      liveAgentUrl +
      "/Visitor/Availability?Availability.ids=" +
      buttonId +
      "&deployment_id=" +
      deploymentId +
      "&org_id=" +
      organizationId;
    console.log("|getAvailability | salesforceLiveChatAPI.js | ", url);
    var options = {
      method: "GET",
      uri: url,
      headers: { "X-Liveagent-Api-Version": apiVersion, },
    };
    try {
      const res = await request(options);
      console.log("|getAvailability | salesforceLiveChatAPI.js | | success");
      resolve(JSON.parse(res));
    } catch (err) {
      console.error("getAvailability | salesforceLiveChatAPI.js |", err);
      reject(err);
    }
  });
}

async function getSession() {
  return new Promise(async (resolve, reject) => {
    var url = liveAgentUrl + "/System/SessionId";
    console.log("|getSession | salesforceLiveChatAPI.js | ", url);
    var options = {
      method: "get",
      uri: url,
      headers: {
        "X-Liveagent-Affinity": "null",
        "X-Liveagent-Api-Version": apiVersion,
      },
    };
    try {
      const result = await request(options);
      console.log("|getSession | salesforceLiveChatAPI.js | success");
      resolve(JSON.parse(result));
    } catch (err) {
      console.error("getSession Error | salesforceLiveChatAPI.js |", err);
      reject(err);
    }
  });
}
async function serverFailtureNotification() {
  console.log( "|serverFailtureNotification | salesforceLiveChatAPI.js | started" );
  var url = config.instance.notificationUrl;
  var options = {
    method: "GET",
    uri: url,
    headers: {},
  };
  try {
    const res = await request(options);
    console.log(
      "|serverFailtureNotification | salesforceLiveChatAPI.js | ended"
    );
  } catch (err) {
    console.error(
      "serverFailtureNotification | salesforceLiveChatAPI.js | ",
      err
    );
    return Promise.reject(err);
  }
}

async function initChat(session, options, data) {
  return new Promise(async (resolve, reject) => {
    console.log( "|initChat | salesforceLiveChatAPI.js | start |", options.buttonId, "|", options.visitorName );
    console.log("flag",data.context.session.BotUserSession.dunningFlag);

    if(data.context.session.BotUserSession.dunningFlag){
      var organizationId = config.live_agent_C2C.organizationId;
      var deploymentId = config.live_agent_C2C.deploymentId;
      var liveAgentUrl = config.live_agent_C2C.liveAgentUrl;
      var BusinessHoursId = config.live_agent_C2C.BusinessHoursId;
      var Priority=config.live_agent_C2C.Priority;
      var UniqueIdentifier=config.live_agent_C2C.UniqueIdentifier;
    }else{
     var organizationId = config.live_agent.organizationId;
     var deploymentId = config.live_agent.deploymentId;
     var liveAgentUrl = config.live_agent.liveAgentUrl;
     var BusinessHoursId = config.live_agent.BusinessHoursId;
     var Priority=config.live_agent.Priority;
     var UniqueIdentifier=config.live_agent.UniqueIdentifier;
    }
    var buttonId = options.buttonId;
    console.log("buttonId"+buttonId,"organizationId"+organizationId,"deploymentId"+deploymentId);
    //console.log("inside initifunction " + JSON.stringify(data));

    var account_number = _.get(data, "context.session.BotUserSession.accountNumber");

    var first_Name = _.get(data, "context.session.BotUserSession.firstName");
    var last_Name = _.get(data, "context.session.BotUserSession.lastName");
    var email = _.get(data, "context.session.BotUserSession.userEmail");
    var subject = _.get(data, "context.session.BotUserSession.subject");
    var description = _.get(data, "context.session.BotUserSession.description");
    var transcript = _.get(data, "context.session.BotUserSession.transcript");
  //  console.log("account number " + account_number+"Transcript"+transcript);
    var visitorName = _.get(options, "VisitorName");
    


    /// AEM (Web SDK) customData 

    var  web_Sdk_AdobeID  =  _.get(data,"context.session.BotUserSession.AdobeID");
    var  web_Sdk_CartID  =  _.get(data,"context.session.BotUserSession.CartID");
    var  web_Sdk_ClientCode  =  _.get(data,"context.session.BotUserSession.ClientCode");
    var  web_Sdk_ClientName  =  _.get(data,"context.session.BotUserSession.ClientName");
    var  web_Sdk_ContactID  =  _.get(data,"context.session.BotUserSession.ContactID");
    var  web_Sdk_ErrorCode  =  _.get(data,"context.session.BotUserSession.ErrorCode");
    var  web_Sdk_Lang  =  _.get(data,"context.session.BotUserSession.Lang");
    var  web_Sdk_LocationIDs  =  _.get(data,"context.session.BotUserSession.LocationIDs");
    var  web_Sdk_OpportunityID  =  _.get(data,"context.session.BotUserSession.OpportunityID");
    var  web_Sdk_ProductCode  =  _.get(data,"context.session.BotUserSession.ProductCode");
    var  web_Sdk_ProductName  =  _.get(data,"context.session.BotUserSession.ProductName");
    var  web_Sdk_Productuser  =  _.get(data,"context.session.BotUserSession.Productuser");
    var  web_Sdk_Question  =  _.get(data,"context.session.BotUserSession.Question");
    var  web_Sdk_SourcePage  =  _.get(data,"context.session.BotUserSession.SourcePage");
    var  web_Sdk_SourceSystem  =  _.get(data,"context.session.BotUserSession.SourceSystem");
    var  web_Sdk_Type  =  _.get(data,"context.session.BotUserSession.Type");
    var  web_Sdk_UltimateParentAccount  =  _.get(data,"context.session.BotUserSession.UltimateParentAccount");
    var  web_Sdk_UserEmail  =  _.get(data,"context.session.BotUserSession.UserEmail");
    var  web_Sdk_UserFirstName  =  _.get(data,"context.session.BotUserSession.UserFirstName");
    var  web_Sdk_UserLastName  =  _.get(data,"context.session.BotUserSession.UserLastName");
    var  web_Sdk_UUID  =  _.get(data,"context.session.BotUserSession.UUID");


    /// Chat Request Details API
    var   user_UUID =  _.get(data, "context.session.BotUserSession.user_UUID");
    var   user_UltimateParentAccount =  _.get(data, "context.session.BotUserSession.user_UltimateParentAccount");
    var   user_Type =  _.get(data, "context.session.BotUserSession.user_Type");
    var   user_Symptom =  _.get(data, "context.session.BotUserSession.user_Symptom");
    var   user_status =  _.get(data, "context.session.BotUserSession.user_status");
    var   user_ShortQuestion =  _.get(data, "context.session.BotUserSession.user_ShortQuestion");
    var   user_ServiceProductName =  _.get(data, "context.session.BotUserSession.user_ServiceProductName");
    var   user_ServiceProductCategorySkill =  _.get(data, "context.session.BotUserSession.user_ServiceProductCategorySkill");
    var   user_ServiceProductCategory =  _.get(data, "context.session.BotUserSession.user_ServiceProductCategory");
    var   user_ProductName =  _.get(data, "context.session.BotUserSession.user_ProductName");
    var   user_ProductID =  _.get(data, "context.session.BotUserSession.user_ProductID");
    var   user_PIIFlag =  _.get(data, "context.session.BotUserSession.user_PIIFlag");
    var   user_LanguageIndicator =  _.get(data, "context.session.BotUserSession.user_LanguageIndicator");
    var   user_Entitlement =  _.get(data, "context.session.BotUserSession.user_Entitlement");
    var   user_EncryptedUUID =  _.get(data, "context.session.BotUserSession.user_EncryptedUUID");
    var   user_DGChatPredictionID =  _.get(data, "context.session.BotUserSession.user_DGChatPredictionID");
    var   user_Country =  _.get(data, "context.session.BotUserSession.user_Country");
    var   user_ContentSet =  _.get(data, "context.session.BotUserSession.user_ContentSet");
    var   user_ContactID =  _.get(data, "context.session.BotUserSession.user_ContactID");
    var   user_Complexity =  _.get(data, "context.session.BotUserSession.user_Complexity");
    var   user_AccountID =  _.get(data, "context.session.BotUserSession.user_AccountID");

        
    console.log("user_UUID ", data.context.session.BotUserSession.user_UUID);
    console.log("user_ProductID  ", data.context.session.BotUserSession.user_ProductID );

    // var firstName = visitorName.split(" ")[0];
    // var lastName = visitorName.split(" ")[1];
    var userAgent = _.get(options, "UserAgent", config.live_agent.userAgent);

    var url = liveAgentUrl + "/Chasitor/ChasitorInit";
    var sessionId = session.id,
      sessionKey = session.key,
      affinityToken = session.affinityToken;

    var prechatDetails = [ 
      {
        "label":"LastName",
        "value":"SFDC",
        "entityMaps":[
           {
              "entityName":"contact",
              "fieldName":"LastName"
           }
        ],
        "transcriptFields":[
           "LastName__c"
        ],
        "displayToAgent":true
     },
     {
        "label":"FirstName",
        "value":"test",
        "entityMaps":[
           {
              "entityName":"contact",
              "fieldName":"FirstName"
           }
        ],
        "transcriptFields":[
           "FirstName__c"
        ],
        "displayToAgent":true
     },
     {
        "label":"Email",
        "value":"test@sfdctest.com",
        "entityMaps":[
           {
              "entityName":"contact",
              "fieldName":"Email"
           }
        ],
        "transcriptFields":[
           "Email__c"
        ],
        "displayToAgent":true
     },
     {
        "label":"Status",
        "value":"Work In Progress",
        "entityMaps":[
           {
              "entityName":"Case",
              "fieldName":"Status"
           }
        ],
        "transcriptFields":[
           "caseStatus__c"
        ],
        "displayToAgent":true
     },
     {
        "label":"Origin",
        "value":"Web",
        "entityMaps":[
           {
              "entityName":"Case",
              "fieldName":"Origin"
           }
        ],
        "transcriptFields":[
           "caseOrigin__c"
        ],
        "displayToAgent":true
     },

     {
        "label":"Subject",
        "value":"TestCaseSubject",
        "entityMaps":[
           {
              "entityName":"Case",
              "fieldName":"Subject"
           }
        ],
        "transcriptFields":[
           "subject__c"
        ],
        "displayToAgent":true
     },
     {
        "label":"Description",
        "value":"TestCaseDescriptionShr",
        "entityMaps":[
           {
              "entityName":"Case",
              "fieldName":"Description"
           }
        ],
        "transcriptFields":[
           "description__c"
        ],
        "displayToAgent":true
     }
        ] ;

    var prechatEntities = [ 
      {
            "entityName":"Contact",         
            "saveToTranscript":"contact",
            "linkToEntityName":"Case",
            "linkToEntityField":"ContactId",
            "entityFieldsMaps":[
              
                {
                  "fieldName":"LastName",
                  "label":"LastName",
                  "doFind":true,
                  "isExactMatch":true,
                  "doCreate":true
               },
               {
                  "fieldName":"FirstName",
                  "label":"FirstName",
                  "doFind":true,
                  "isExactMatch":true,
                  "doCreate":true
               },
               {
                  "fieldName":"Email",
                  "label":"Email",
                  "doFind":true,
                  "isExactMatch":true,
                  "doCreate":true
               }
                          
            ]
         },
          {
            "entityName":"Case",
            "showOnCreate":true,          
            "saveToTranscript":"Case",
            "entityFieldsMaps":[
               {
                  "fieldName":"Status",
                  "label":"Status",
                  "doFind":false,
                  "isExactMatch":false,
                  "doCreate":true
               },
               {
                  "fieldName":"Origin",
                  "label":"Origin",
                  "doFind":false,
                  "isExactMatch":false,
                  "doCreate":true
               },  
   
            {
                  "fieldName":"Subject",
                  "label":"Subject",
                  "doFind":false,
                  "isExactMatch":false,
                  "doCreate":true
               },
               {
                  "fieldName":"Description",
                  "label":"Description",
                  "doFind":false,
                  "isExactMatch":false,
                  "doCreate":true
               }         
            ]             
           
         }      
         
      ];

    var body = {
      organizationId: organizationId,
      deploymentId: deploymentId,
      sessionId: sessionId,
      buttonId: buttonId,
      screenResolution: screenResolution,
      userAgent: userAgent,
      language: language,
      visitorName: visitorName,
      prechatDetails: prechatDetails,
      prechatEntities: prechatEntities,
      receiveQueueUpdates: true,
      isPost: true,
    };
    var option = {
      method: "POST",
      uri: url,
      body: body,
      json: true,
      headers: {
        "X-Liveagent-Sequence": "1",
        "X-Liveagent-Affinity": affinityToken,
        "X-Liveagent-Session-Key": sessionKey,
        "X-Liveagent-Api-Version": apiVersion,
      },
    };
    var id = option.contactId != "" ? option.contactId : option.psid;
    console.log("|initChat | salesforceLiveChatAPI.js | BeforeInitiatingRequest |",visitorName,"|",id);
    try {
      const res = await request(option);
      console.log("|initChat | salesforceLiveChatAPI.js | Successfully initiallized |",visitorName,"|",id);
      resolve(res);
    } catch (err) {
     // console.log(err);
     // console.error("initChat | salesforceLiveChatAPI.js | Chat Failed |", err.message);
      reject(err);
    }
  });
}

async function sendMsg(session_key, affinity_token, data) {
  return new Promise(async (resolve, reject) => {
  //  console.log("in sendMessage API");
    if (data.text === undefined) data.text = "";
    //console.log("in sendMessage API " + data.text);
    var url = liveAgentUrl + "/Chasitor/ChatMessage";
    var options = {
      method: "POST",
      uri: url,
      body: data,
      json: true,
      headers: {
        "X-LIVEAGENT-API-VERSION": apiVersion,
        "X-LIVEAGENT-AFFINITY": affinity_token,
        "X-LIVEAGENT-SESSION-KEY": session_key,
      },
    };
    console.log(
      "|sendMsg | salesforceLiveChatAPI.js | Before Sending Message |",
      options.uri
    );
    try {
      //console.log("|sendMsg | salesforceLiveChatAPI.js |", options.uri, "Before API Call");
      const res = await request(options);
      console.log(
        "|sendMsg | salesforceLiveChatAPI.js |",
        options.uri,
        "success"
      );
      resolve(res);
    } catch (err) {
      console.error("sendMsg | salesforceLiveChatAPI.js |", err, "failed");
      reject(err);
    }
  });
}

async function getPendingMessages(session_key, affinity_token) {
  return new Promise(async (resolve, reject) => {
    var url = liveAgentUrl + "/System/Messages";
    var options = {
      method: "GET",
      uri: url,
      headers: {
        "X-LIVEAGENT-API-VERSION": apiVersion,
        "X-LIVEAGENT-AFFINITY": affinity_token,
        "X-LIVEAGENT-SESSION-KEY": session_key,
      },
    };
    console.log(
      "|getPendingMessages | salesforceLiveChatAPI.js | ",
      options.uri
    );
    try {
    //  console.log("Will call System Message API now");
      const res = await request(options);
     // console.log(res);
      if (IsJsonString(res)) {
        resolve(JSON.parse(res));
      }
      resolve({ messages: [] });
    } catch (err) {
      console.error(
        "getPendingMessages | salesforceLiveChatAPI.js | ",
        err.statusCode
      );
      reject(err);
    }
  });
}

async function endChat(session_key, affinity_token) {
  console.log("|endChat | salesforceLiveChatAPI.js | ", session_key);
  var url = liveAgentUrl + "/Chasitor/ChatEnd";
  var options = {
    method: "post",
    uri: url,
    body: { reason: "client" },
    json: true,
    headers: {
      "X-LIVEAGENT-API-VERSION": apiVersion,
      "X-LIVEAGENT-AFFINITY": affinity_token,
      "X-LIVEAGENT-SESSION-KEY": session_key,
    },
  };
  console.log(
    "|endChat | salesforceLiveChatAPI.js | ",  session_key, " | ", url);
  try {
    const res = await request(options);
    console.log("|endChat | salesforceLiveChatAPI.js | success");
    Promise.resolve(res);
  } catch (err) {
    console.error("endChat | salesforceLiveChatAPI.js | error |", err);
    return Promise.reject(err);
  }
}


function IsJsonString(str) {
  try {
    JSON.parse(str);
  } catch (e) {
    return false;
  }
  return true;
}


module.exports.initChat = initChat;
module.exports.sendMsg = sendMsg;
module.exports.getPendingMessages = getPendingMessages;
module.exports.getSession = getSession;
module.exports.endChat = endChat;
module.exports.serverFailtureNotification = serverFailtureNotification;
module.exports.getAvailability = getAvailability;

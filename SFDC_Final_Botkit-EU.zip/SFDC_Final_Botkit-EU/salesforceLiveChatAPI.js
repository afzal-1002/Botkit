var Promise = require("bluebird");
var request = require("request-promise");
var _ = require("lodash");

// Loading config files
var sfdc_config_file = require("./config.json").sfdc_config_file;
var config = require(sfdc_config_file);

// Global Config
var liveAgentUrl = config.live_agent.liveAgentUrl;
var buttonId = config.live_agent.buttonId;
var apiVersion = config.live_agent.apiVersion;
var screenResolution = config.live_agent.screenResolution;
var language = config.live_agent.language;
var organizationId = config.live_agent.organizationId;
var deploymentId = config.live_agent.deploymentId;

async function getAvailability() {
  return new Promise(async (resolve, reject) => {
    var url =
      liveAgentUrl +
      "/Visitor/Availability?Availability.ids=" +
      buttonId +
      "&deployment_id=" +
      deploymentId +
      "&org_id=" +
      organizationId;
    console.log("|getAvailability | salesforceLiveChatAPI.js | ", url);
    var options = {
      method: "GET",
      uri: url,
      headers: { "X-Liveagent-Api-Version": apiVersion },
    };
    try {
      const res = await request(options);
      console.log("|getAvailability | salesforceLiveChatAPI.js | | success");
      resolve(JSON.parse(res));
    } catch (err) {
      console.error("getAvailability | salesforceLiveChatAPI.js |", err);
      reject(err);
    }
  });
}

async function getSession() {
  return new Promise(async (resolve, reject) => {
    var url = liveAgentUrl + "/System/SessionId";
    console.log("|getSession | salesforceLiveChatAPI.js | getSession Url \n " + url);
    var options = {
      method: "GET",
      uri: url,
      headers: {
        "X-Liveagent-Affinity": "null",
        "X-Liveagent-Api-Version": apiVersion,
      },
    };
    try {
      const result = await request(options);
      console.log("|getSession | salesforceLiveChatAPI.js | success ");
      resolve(JSON.parse(result));
    } catch (err) {
      console.error("getSession Error | salesforceLiveChatAPI.js |", err);
      reject(err);
    }
  });
}

// ✅ Added Missing Function: `serverFailtureNotification`
async function serverFailtureNotification() {
  console.log("|serverFailtureNotification | salesforceLiveChatAPI.js | started");
  var url = config.instance.notificationUrl;
  var options = {
    method: "GET",
    uri: url,
    headers: {},
  };
  try {
    const res = await request(options);
    console.log("|serverFailtureNotification | salesforceLiveChatAPI.js | ended");
  } catch (err) {
    console.error("serverFailtureNotification | salesforceLiveChatAPI.js | ", err);
    return Promise.reject(err);
  }
}

async function initChat(session, options, data) {
  return new Promise(async (resolve, reject) => {
    console.log("|initChat | salesforceLiveChatAPI.js | start |", options.buttonId, "|", options.visitorName);
    console.log("flag", data.context.session.BotUserSession.dunningFlag);

    if (data.context.session.BotUserSession.dunningFlag) {
      var organizationId = config.live_agent_C2C.organizationId;
      var deploymentId = config.live_agent_C2C.deploymentId;
      var liveAgentUrl = config.live_agent_C2C.liveAgentUrl;
    } else {
      var organizationId = config.live_agent.organizationId;
      var deploymentId = config.live_agent.deploymentId;
      var liveAgentUrl = config.live_agent.liveAgentUrl;
    }
    
    var buttonId = options.buttonId;
    console.log("buttonId " + buttonId + " organizationId " + organizationId + " deploymentId " + deploymentId);

    var userAgent = _.get(options, "UserAgent", config.live_agent.userAgent);
    console.log(" userAgent " + userAgent);

    var url = liveAgentUrl + "/Chasitor/ChasitorInit";
    var sessionId = session.id,
      sessionKey = session.key,
      affinityToken = session.affinityToken;

    var prechatDetails = [];
    var prechatEntities = [];
    var visitorName = _.get(options, "VisitorName");

    var body = {
      organizationId: organizationId,
      deploymentId: deploymentId,
      sessionId: sessionId,
      buttonId: buttonId,
      screenResolution: screenResolution,
      userAgent: userAgent,
      language: language,
      visitorName: visitorName,
      prechatDetails: prechatDetails,
      prechatEntities: prechatEntities,
      receiveQueueUpdates: true,
      isPost: true,
    };

    var option = {
      method: "POST",
      uri: url,
      body: body,
      json: true,
      headers: {
        "X-Liveagent-Sequence": "1",
        "X-Liveagent-Affinity": affinityToken,
        "X-Liveagent-Session-Key": sessionKey,
        "X-Liveagent-Api-Version": apiVersion,
      },
    };

    var id = (option.contactId && option.contactId !== "") ? option.contactId : (option.psid || "Unknown_ID");

    console.log("|initChat | salesforceLiveChatAPI.js | BeforeInitiatingRequest |", visitorName, "| Id ", id);
    try {
      const res = await request(option);
      console.log("|initChat | salesforceLiveChatAPI.js | Successfully initiallized |", visitorName, "| Id", id);
      resolve(res);
    } catch (err) {
      reject(err);
    }
  });
}

// ✅ Added Missing Function: `sendMsg`
async function sendMsg(session_key, affinity_token, data) {
  return new Promise(async (resolve, reject) => {
    console.log("in sendMsg API");
    if (data.text === undefined) data.text = "";
    console.log("in sendMessage API " + data.text);
    var url = liveAgentUrl + "/Chasitor/ChatMessage";
    var options = {
      method: "POST",
      uri: url,
      body: data,
      json: true,
      headers: {
        "X-LIVEAGENT-API-VERSION": apiVersion,
        "X-LIVEAGENT-AFFINITY": affinity_token,
        "X-LIVEAGENT-SESSION-KEY": session_key,
      },
    };
    console.log("|sendMsg | salesforceLiveChatAPI.js | Before Sending Message |", options.uri);
    try {
      const res = await request(options);
      console.log("|sendMsg | salesforceLiveChatAPI.js | success");
      resolve(res);
    } catch (err) {
      console.error("sendMsg | salesforceLiveChatAPI.js |", err, "failed");
      reject(err);
    }
  });
}

// ✅ Added Missing Function: `getPendingMessages`
async function getPendingMessages(session_key, affinity_token) {
  return new Promise(async (resolve, reject) => {
    var url = liveAgentUrl + "/System/Messages";
    var options = {
      method: "GET",
      uri: url,
      headers: {
        "X-LIVEAGENT-API-VERSION": apiVersion,
        "X-LIVEAGENT-AFFINITY": affinity_token,
        "X-LIVEAGENT-SESSION-KEY": session_key,
      },
    };
    console.log("|getPendingMessages | salesforceLiveChatAPI.js | ", options.uri);
    try {
      const res = await request(options);
      if (IsJsonString(res)) {
        resolve(JSON.parse(res));
      }
      resolve({ messages: [] });
    } catch (err) {
      console.error("getPendingMessages | salesforceLiveChatAPI.js | ", err.statusCode);
      reject(err);
    }
  });
}

async function endChat(session_key, affinity_token) {
  console.log("|endChat | salesforceLiveChatAPI.js | ", session_key);
  var url = liveAgentUrl + "/Chasitor/ChatEnd";
  var options = {
    method: "post",
    uri: url,
    body: { reason: "client" },
    json: true,
    headers: {
      "X-LIVEAGENT-API-VERSION": apiVersion,
      "X-LIVEAGENT-AFFINITY": affinity_token,
      "X-LIVEAGENT-SESSION-KEY": session_key,
    },
  };
  console.log(
    "|endChat | salesforceLiveChatAPI.js | ",  session_key, " | ", url);
  try {
    const res = await request(options);
    console.log("|endChat | salesforceLiveChatAPI.js | success");
    Promise.resolve(res);
  } catch (err) {
    console.error("endChat | salesforceLiveChatAPI.js | error |", err);
    return Promise.reject(err);
  }
}


function IsJsonString(str) {
  try {
    JSON.parse(str);
  } catch (e) {
    return false;
  }
  return true;
}


module.exports.initChat = initChat;
module.exports.getSession = getSession;
module.exports.getAvailability = getAvailability;
module.exports.endChat = endChat;
module.exports.serverFailtureNotification = serverFailtureNotification;
module.exports.sendMsg = sendMsg;
module.exports.getPendingMessages = getPendingMessages;
